#!/bin/sh
sleep 5s
cd /home/pi/temp_control/
./temp_control
